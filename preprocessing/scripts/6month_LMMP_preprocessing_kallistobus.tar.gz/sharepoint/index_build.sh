

cd /home-2/jslosbe1@jhu.edu/scratch/Kulkarni_ENS_analysis/6mo_LMMP/kallisto/bustools_required_files_10xv2_mm

kallisto index -i mm_cDNA_introns_mm_10xv2.idx -k 31 cDNA_introns.fa



echo "we got here"


